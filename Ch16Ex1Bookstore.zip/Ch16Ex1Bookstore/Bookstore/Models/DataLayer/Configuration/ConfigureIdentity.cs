﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Bookstore.Models
{
    public static class ConfigureIdentity
    {
        public static async Task CreateAdminUserAsync(IServiceProvider services)
        {
            var userManager =
                services.GetRequiredService<UserManager<User>>();

            var roleManager =
                services.GetRequiredService<RoleManager<IdentityRole>>();

            string username = "admin";
            string password = "Sesame";
            string roleName = "Admin";

            if (!await roleManager.RoleExistsAsync(roleName))
            {
                await roleManager.CreateAsync(
                    new IdentityRole(roleName));
            }

            User? user = await userManager.FindByNameAsync(username);

            if (user == null)
            {
                user = new User
                {
                    UserName = username,
                    Email = "admin@test.com"
                };

                var result =
                    await userManager.CreateAsync(user, password);

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(user, roleName);
                }
            }
        }
    }
}