﻿using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;

namespace ClassSchedule.Views.Shared.Components
{
    public class DayFilter : ViewComponent
    {
        private IRepository<Day> data;

        public DayFilter(IRepository<Day> repo)
        {
            data = repo;
        }

        public IViewComponentResult Invoke()
        {
            var days = data.List(new QueryOptions<Day>
            {
                OrderBy = d => d.DayId
            });

            return View(days);
        }
    }
}