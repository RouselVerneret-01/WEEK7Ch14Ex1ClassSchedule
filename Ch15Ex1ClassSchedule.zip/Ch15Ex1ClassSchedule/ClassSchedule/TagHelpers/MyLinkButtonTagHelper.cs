﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.AspNetCore.Routing;

namespace ClassSchedule.TagHelpers
{
    [HtmlTargetElement("my-link-button")]
    public class MyLinkButtonTagHelper : TagHelper
    {
        private LinkGenerator linkGenerator;

        [ViewContext]
        public ViewContext? ViewContext { get; set; }

        public string? Action { get; set; }
        public string? Controller { get; set; }
        public int Id { get; set; }

        public MyLinkButtonTagHelper(LinkGenerator lg)
        {
            linkGenerator = lg;
        }

        public override void Process(TagHelperContext context,
     TagHelperOutput output)
        {
            if (ViewContext == null)
            {
                return;
            }

            if (Action == null)
            {
                Action = ViewContext.RouteData.Values["action"]?.ToString();
            }

            if (Controller == null)
            {
                Controller = ViewContext.RouteData.Values["controller"]?.ToString();
            }

            var routeValues = new
            {
                id = Id
            };

            string? url = linkGenerator.GetPathByAction(
                ViewContext.HttpContext,
                Action,
                Controller,
                routeValues);

            output.TagName = "a";

            output.Attributes.SetAttribute("href", url);

            output.Attributes.SetAttribute("class",
                "btn btn-outline-dark");
        }
    }
}