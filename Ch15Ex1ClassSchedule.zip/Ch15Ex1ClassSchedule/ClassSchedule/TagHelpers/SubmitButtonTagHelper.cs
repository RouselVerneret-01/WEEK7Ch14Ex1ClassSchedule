﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace ClassSchedule.TagHelpers
{
    [HtmlTargetElement("submit-button")]
    public class SubmitButtonTagHelper : TagHelper
    {
        public override void Process(TagHelperContext context,
            TagHelperOutput output)
        {
            output.TagName = "button";

            output.Attributes.SetAttribute("type", "submit");

            output.Attributes.Add("class",
     "btn btn-primary");

            output.Content.SetContent("Save");
        }
    }
}